/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_autoFunc_d_fk_dc_info.h
 *
 * MATLAB Coder version            : 5.1
 * C/C++ source code generated on  : 10-Aug-2021 14:50:52
 */

#ifndef _CODER_AUTOFUNC_D_FK_DC_INFO_H
#define _CODER_AUTOFUNC_D_FK_DC_INFO_H

/* Include Files */
#include "mex.h"
#ifdef __cplusplus

extern "C" {

#endif

  /* Function Declarations */
  MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#ifdef __cplusplus

}
#endif
#endif

/*
 * File trailer for _coder_autoFunc_d_fk_dc_info.h
 *
 * [EOF]
 */
