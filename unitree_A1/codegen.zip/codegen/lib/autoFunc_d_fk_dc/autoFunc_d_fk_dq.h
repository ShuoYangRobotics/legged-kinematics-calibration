//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: autoFunc_d_fk_dq.h
//
// MATLAB Coder version            : 5.1
// C/C++ source code generated on  : 10-Aug-2021 14:50:52
//
#ifndef AUTOFUNC_D_FK_DQ_H
#define AUTOFUNC_D_FK_DQ_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
extern void autoFunc_d_fk_dq(const double in1[3], const double in2[3], const
  double in3[5], double jacobian[9]);

#endif

//
// File trailer for autoFunc_d_fk_dq.h
//
// [EOF]
//
